# Ludum Dare 44!

Crafty JS Docs:
- [http://craftyjs.com/api/Collision.html#-collision](
http://craftyjs.com/api/Collision.html#-collision)


Available here:
- [https://s3-us-west-1.amazonaws.com/ludum-dare-44/master/index.html](
https://s3-us-west-1.amazonaws.com/ludum-dare-44/master/index.html)
