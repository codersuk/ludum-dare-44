Crafty.c("Platform", {
	init : function () {
		this.requires('2D, DOM')
	},
});
